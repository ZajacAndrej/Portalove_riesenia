<?php
include_once "db.php";

use portalove\DB;

$db = new DB("localhost", "portalove_riesenia", "root", "", 3306);

global $db;

session_start();
