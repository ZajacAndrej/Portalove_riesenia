<?php
include_once "db_connect.php";

$db = $GLOBALS['db'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Motor Website Template</title>
    <meta name="description" content="">
    <!-- 
Motor Template
http://www.templatemo.com/tm-463-motor
-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>

<body>
    <section class="container tm-contact-main">
        <?php
        if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true) {
            $cars = $db->get_cars();
            echo '<div class="about-container-2 about-title-2">';
            echo '<a href="insert_form.php" class="about-link about-link-2">Insert Car</a><br>';
            echo '<a href="index.php" class="about-link about-link-2">Web page</a><br>';
            echo '<a href="logout.php" class="about-link about-link-2">Logout</a><br>';
            echo '</div>';
            foreach ($cars as $car) {

                echo '<li class="about-title-2 about-container-2"> id: '
                    . $car['id'] . "  " . $car['category'] . "  " . $car['model'] .
                    '<a href="delete.php?id=' . $car['id'] . '" class="about-link about-link-2">Delete</a> 
                    <a href="update_form.php?id=' . $car['id'] . '" class="about-link about-link-2">Update</a> 
                    </li>';
            }
        } else {
        ?>

            <div class="contact-form-container">
                <form method="post" action="login.php" class="tm-contact-form">
                    <div class=" form-group">
                        <input type="text" name="username" value="" placeholder="USERNAME" class="form-control"><br>
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" value="" placeholder="PASSWORD" class="form-control"><br>
                    </div>
                    <div class="col-lg-12 col-md-12 submit-btn-container">
                        <input type="submit" name="submit" value="Login" class="btn text-uppercase templatemo-submit-btn">
                    </div>
                </form>
            </div>

        <?php
        }
        ?>
    </section>
</body>

</html>