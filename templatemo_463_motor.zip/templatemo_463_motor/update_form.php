<?php
include_once "db_connect.php";

$db = $GLOBALS['db'];
$categories = $db->get_categories();
$car = $db->get_car($_GET['id']);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Motor Website Template</title>
    <meta name="description" content="">
    <!-- 
Motor Template
http://www.templatemo.com/tm-463-motor
-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

</head>

<body>
    <section class="container tm-contact-main">
        <div class="contact-form-container">
            <form method="post" action="update.php" class="tm-contact-form">
                Category: <br>
                <div class="form-group">
                    <select name="category">
                        <?php
                        foreach ($categories as $id => $category) {
                            if ($id === $car['category_id']) {
                                echo '<option value="' . $id . '" selected>' . $category . '</option>';
                            } else {
                                echo '<option value="' . $id . '">' . $category . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class=" form-group">
                    <input type="text" name="model" value="<?php echo $car['model'] ?>" placeholder="MODEL" class="form-control"><br>
                </div>

                <div class="form-group">
                    <input type="text" name="img" value="<?php echo $car['img'] ?>" placeholder="IMG" class="form-control"><br>
                </div>

                <div class="form-group">
                    <textarea id="contact_message" class="form-control" rows="6" placeholder="DESCRIPTION" name="description"><?php echo $car['description'] ?></textarea>
                </div>

                <div class="form-group">
                    <input type="text" name="price" value="<?php echo $car['price'] ?>" placeholder="PRICE" class="form-control"><br>
                    <input type="hidden" name="id" value="<?php echo $car['id']; ?>">
                </div>
                <div class="col-lg-12 col-md-12 submit-btn-container">
                    <input type="submit" name="submit" value="Update" class="btn text-uppercase templatemo-submit-btn">
                </div>
            </form>
        </div>
    </section>
</body>

</html>