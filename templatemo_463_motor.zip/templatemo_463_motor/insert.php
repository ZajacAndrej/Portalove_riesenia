<?php
include_once "db_connect.php";

$db = $GLOBALS['db'];

if (isset($_POST['submit'])) {
    $insert = $db->insert_car(
        $_POST['model'],
        $_POST['img'],
        $_POST['description'],
        $_POST['price'],
        $_POST['category']
    );

    if ($insert) {
        header('Location: admin.php');
    } else {
        echo "FATAL ERROR!!";
    }
} else {
    header('Location: admin.php');
}
