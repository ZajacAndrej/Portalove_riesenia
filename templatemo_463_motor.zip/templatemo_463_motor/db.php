<?php

namespace portalove;

class DB {
    private $host;
    private $dbName;
    private $username;
    private $password;
    private $port;

    private $connection;

    public function __construct($host, $dbName, $username, $password, $port = 3306) {
        $this->host = $host;
        $this->dbName = $dbName;
        $this->username = $username;
        $this->password = $password;
        $this->port = $port;

        try {
            $this->connection = new \PDO("mysql:host=$host;dbname=$dbName;port=$port", $username, $password);
            // set the PDO error mode to exception
            $this->connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }

    public function get_menu_items() {
        $menuItems = [];
        $sql = "SELECT * FROM menu";

        try {
            $query = $this->connection->query($sql);
            while ($row = $query->fetch()) {
                $menuItems[] = [
                    'name' => $row['display_name'],
                    'url' => $row['path']
                ];
            }
            return  $menuItems;
        } catch (\PDOException $e) {
            return [];
        }
    }

    public function login($username, $password) {
        $hash = sha1($password);
        $sql = "SELECT COUNT(id) AS is_admin FROM user WHERE username = '" . $username . "' AND password = '" . $hash . "'";

        try {
            $query = $this->connection->query($sql);
            $userExists = $query->fetch(\PDO::FETCH_ASSOC);
            if (intval($userExists['is_admin']) === 1) {
                return true;
            } else {
                return false;
            }
        } catch (\PDOException $e) {
            return false;
        }
    }

    public function get_categories() {
        $categories = [];
        $sql = "SELECT * FROM category";

        try {
            $query = $this->connection->query($sql);
            while ($row = $query->fetch(\PDO::FETCH_ASSOC)) {
                $categories[$row['id']] = $row['category'];
            }
            return  $categories;
        } catch (\PDOException $e) {
            return [];
        }
    }

    public function insert_car($model, $img, $description, $price, $category) {
        $sqlCar = "INSERT INTO car(price,img,model,description,created_at,updated_at,category_id)
                           VALUE ('" . $price . "', '" . $img . "', '" . $model . "', '" . $description . "', NOW(), NOW(), '" . $category . "')";
        try {
            $this->connection->query($sqlCar);
            return true;
        } catch (\PDOException $e) {
            return false;
        }
    }

    public function get_car($id) {
        $car = [];
        $sql = "SELECT * FROM car WHERE id = " . $id;
        try {
            $query = $this->connection->query($sql);
            while ($row = $query->fetch(\PDO::FETCH_ASSOC)) {
                $car = [
                    'id' => $row['id'],
                    'price' => $row['price'],
                    'img' => $row['img'],
                    'model' => $row['model'],
                    'description' => $row['description'],
                    'category_id' => $row['category_id'],
                ];
            }
            return  $car;
        } catch (\PDOException $e) {
            return [];
        }
    }

    public function get_cars() {
        $cars = [];
        $sql = "SELECT car.id, price, img, model, description, category FROM car
                INNER JOIN category on car.category_id = category.id";
        try {
            $query = $this->connection->query($sql);
            while ($row = $query->fetch(\PDO::FETCH_ASSOC)) {
                $cars[] = [
                    'id' => $row['id'],
                    'price' => $row['price'],
                    'img' => $row['img'],
                    'model' => $row['model'],
                    'description' => $row['description'],
                    'category' => $row['category'],
                ];
            }
            return  $cars;
        } catch (\PDOException $e) {
            return [];
        }
    }

    public function get_category_cars($category) {
        $cars = [];
        $sql = "SELECT car.id, price, img, model, description FROM car
                INNER JOIN category on car.category_id = category.id
                WHERE category = '" . $category . "'";
        try {
            $query = $this->connection->query($sql);
            while ($row = $query->fetch(\PDO::FETCH_ASSOC)) {
                $cars[] = [
                    'id' => $row['id'],
                    'price' => $row['price'],
                    'img' => $row['img'],
                    'model' => $row['model'],
                    'description' => $row['description'],
                    'category' => $category,
                ];
            }
            return  $cars;
        } catch (\PDOException $e) {
            return [];
        }
    }

    public function get_category_car_count($category) {
        $sql = "SELECT COUNT(car.id) AS count FROM car
                INNER JOIN category on car.category_id = category.id
                WHERE category = '" . $category . "'";

        try {
            $query = $this->connection->query($sql);
            $count = $query->fetch(\PDO::FETCH_ASSOC);
            return $count['count'];
        } catch (\PDOException $e) {
            return false;
        }
    }

    public function update_car($id, $model, $img, $description, $price, $category) {
        $sql = "UPDATE car 
                SET model = '" . $model . "', img = '" . $img . "', description = '" . $description . "', updated_at = NOW(), price= '" . $price . "', category_id = '" . $category . "' 
                WHERE id =" . $id;
        try {
            $this->connection->query($sql);
            return true;
        } catch (\PDOException $e) {
            return false;
        }
    }

    public function delete_car($id) {
        $sql = "DELETE FROM car WHERE id = " . $id;

        try {
            $this->connection->query($sql);
            return true;
        } catch (\PDOException $e) {
            return false;
        }
    }
}
